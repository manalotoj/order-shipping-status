# src/order_shipping_status/api/normalize.py
from __future__ import annotations

from typing import Any, Dict, Tuple
import pandas as pd


def _from_latest_status_detail(payload: Dict[str, Any]) -> Tuple[str, str, str, str]:
    """
    Try to extract (code, derivedCode, statusByLocale, description) from
    output.completeTrackResults[*].trackResults[*].latestStatusDetail.
    """
    out = payload.get("output", payload)
    if not isinstance(out, dict):
        return "", "", "", ""

    ctr = out.get("completeTrackResults")
    if not isinstance(ctr, list) or not ctr:
        return "", "", "", ""

    tr_list = ctr[0].get("trackResults")
    if not isinstance(tr_list, list) or not tr_list:
        return "", "", "", ""

    lsd = tr_list[0].get("latestStatusDetail") or {}
    if not isinstance(lsd, dict):
        return "", "", "", ""

    code = str(lsd.get("code") or "")
    derived = str(lsd.get("derivedCode") or code)
    status = str(lsd.get("statusByLocale") or "")
    desc = str(lsd.get("description") or "")
    return code, derived, status, desc


def _from_scan_events(payload: Dict[str, Any]) -> Tuple[str, str, str, str]:
    """
    Fallback to scanEvents (either top-level or nested) when latestStatusDetail
    is not available. Use the FIRST event present (unit tests only require a sane fallback).
    """
    candidates = []

    # top-level scanEvents
    se = payload.get("scanEvents")
    if isinstance(se, list) and se:
        candidates.append(se)

    # nested under output.completeTrackResults[*].trackResults[*].scanEvents
    out = payload.get("output", payload)
    if isinstance(out, dict):
        ctr = out.get("completeTrackResults")
        if isinstance(ctr, list):
            for cr in ctr:
                if not isinstance(cr, dict):
                    continue
                tr_list = cr.get("trackResults")
                if isinstance(tr_list, list):
                    for tr in tr_list:
                        if not isinstance(tr, dict):
                            continue
                        se2 = tr.get("scanEvents")
                        if isinstance(se2, list) and se2:
                            candidates.append(se2)

    for events in candidates:
        ev = events[0]
        if isinstance(ev, dict):
            code = str(ev.get("derivedStatusCode")
                       or ev.get("eventType") or "")
            derived = str(ev.get("derivedStatusCode") or code)
            status = str(ev.get("derivedStatus")
                         or ev.get("eventDescription") or "")
            desc = str(ev.get("eventDescription") or "")
            return code, derived, status, desc

    return "", "", "", ""


def _from_flat(payload: Dict[str, Any]) -> Tuple[str, str, str, str]:
    """
    Final fallback: respect flat shapes used in unit tests.
    """
    code = str(payload.get("code") or "")
    derived = str(payload.get("derivedCode") or code)
    status = str(payload.get("statusByLocale") or "")
    desc = str(payload.get("description") or "")
    return code, derived, status, desc


def _latest_event_ts_utc(payload: Dict[str, Any]) -> str:
    """Return latest timestamp across scanEvents.date and dateAndTimes.dateTime

    Searches top-level and nested paths used by FedEx output. Returns an ISO8601
    UTC string (with trailing 'Z') or empty string when nothing parseable found.
    """
    candidates = []

    def _add(obj, key):
        if isinstance(obj, dict):
            v = obj.get(key)
            if v:
                candidates.append(v)

    # top-level scanEvents/dateAndTimes
    se = payload.get("scanEvents")
    if isinstance(se, list):
        for ev in se:
            _add(ev, "date")

    dat = payload.get("dateAndTimes")
    if isinstance(dat, list):
        for d in dat:
            _add(d, "dateTime")

    # nested under output.completeTrackResults[*].trackResults[*]
    out = payload.get("output", payload)
    if isinstance(out, dict):
        ctr = out.get("completeTrackResults")
        if isinstance(ctr, list):
            for cr in ctr:
                if not isinstance(cr, dict):
                    continue
                tr_list = cr.get("trackResults")
                if isinstance(tr_list, list):
                    for tr in tr_list:
                        if not isinstance(tr, dict):
                            continue
                        se2 = tr.get("scanEvents")
                        if isinstance(se2, list):
                            for ev in se2:
                                _add(ev, "date")
                        dat2 = tr.get("dateAndTimes")
                        if isinstance(dat2, list):
                            for d in dat2:
                                _add(d, "dateTime")

    if not candidates:
        return ""

    # Use pandas for robust parsing and utc normalization
    ts = pd.to_datetime(candidates, utc=True, errors="coerce")
    ts = ts.dropna()
    if ts.empty:
        return ""
    latest = ts.max()
    iso = latest.isoformat()
    if iso.endswith("+00:00"):
        iso = iso.replace("+00:00", "Z")
    return iso


def _carrier_from_code(carrier_code: str) -> str:
    """
    Light mapping just so required 'carrier' field is non-empty.
    """
    cc = (carrier_code or "").upper()
    if cc.startswith("FDX") or cc.startswith("FEDEX"):
        return "FedEx"
    return cc or "Unknown"


def normalize_fedex(
    payload: Dict[str, Any],
    *,
    tracking_number: str,
    carrier_code: str,
    source: str,  # kept for signature parity; not used in core fields
):
    """
    Produce a NormalizedShippingData object with the core status fields populated:
      - code
      - derivedCode
      - statusByLocale
      - description

    Other required fields in NormalizedShippingData are filled with neutral defaults.
    Timestamp/backfill (LatestEventTimestampUtc) is intentionally NOT performed here
    to keep unit tests deterministic; that happens later during enrichment/processing.
    """
    # If the payload contains a batch of completeTrackResults, try to narrow
    # the payload down to the matching entry for this tracking number so our
    # helpers examine the correct record (avoid taking ctr[0] blindly).
    focus_payload = payload
    try:
        out = payload.get("output", payload) if isinstance(
            payload, dict) else payload
        if isinstance(out, dict):
            ctr = out.get("completeTrackResults")
            if isinstance(ctr, list) and len(ctr) > 1:
                match = None
                for cr in ctr:
                    if not isinstance(cr, dict):
                        continue
                    # direct trackingNumber on the container
                    if str(cr.get("trackingNumber") or "") == str(tracking_number):
                        match = cr
                        break
                    # check nested trackResults[*].trackingNumberInfo.trackingNumber
                    tr_list = cr.get("trackResults")
                    if isinstance(tr_list, list):
                        for tr in tr_list:
                            if not isinstance(tr, dict):
                                continue
                            tinfo = tr.get("trackingNumberInfo") or {}
                            if str(tinfo.get("trackingNumber") or "") == str(tracking_number):
                                match = cr
                                break
                        if match:
                            break
                if match is not None:
                    focus_payload = {"output": {
                        "completeTrackResults": [match]}}
    except Exception:
        # Best-effort scoping; fall back to original payload on any error
        focus_payload = payload

    # 1) Deep, official path
    code, derived, status, desc = _from_latest_status_detail(focus_payload)

    # 2) Fallback: scanEvents (top-level or nested)
    if not code and not status:
        code, derived, status, desc = _from_scan_events(focus_payload)

    # 3) Fallback: flat shape (unit tests rely on this)
    if not code and not status:
        code, derived, status, desc = _from_flat(focus_payload)

    # Import here to avoid circulars on module import
    from order_shipping_status.models import NormalizedShippingData

    # Construct with required fields + safe defaults
    return NormalizedShippingData(
        code=code,
        derivedCode=derived,
        statusByLocale=status,
        description=desc,

        # Required by your model (use safe defaults)
        carrier=_carrier_from_code(carrier_code),
        tracking_number=str(tracking_number or ""),
        carrier_code=str(carrier_code or ""),
        actual_delivery_dt="",
        possession_status=False,
        service_type="",
        service_desc="",
        origin_city="",
        origin_state="",
        dest_city="",
        dest_state="",
        received_by_name="",

        # Keep the raw payload attached
        raw=payload,
    )
